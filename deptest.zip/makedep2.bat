@echo off
REM Set compiler flags
set CompilerFlags=-O3 -std=c++17 -lineinfo -maxrregcount=128 --ptxas-options=-v --use_fast_math --gpu-architecture=sm_89 -IC:/Users/Lenovo/Desktop/Projektek/UniDEM/GPUDEM
 
REM Compile with nvcc
nvcc -o GPUDEM.exe %CompilerFlags% ex8_movingTool_deposit2.cu

.\GPUDEM.exe
